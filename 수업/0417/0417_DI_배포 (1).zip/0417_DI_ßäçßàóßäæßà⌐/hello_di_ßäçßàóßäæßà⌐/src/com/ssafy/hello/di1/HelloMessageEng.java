package com.ssafy.hello.di1;

public class HelloMessageEng {

	public String helloEng(String name) {
		return "Hello " + name;
	}
	
}

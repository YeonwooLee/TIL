package com.ssafy.hello.di1;

public class HelloMessageKor {

	public String helloKor(String name) {
		return "안녕하세요 " + name;
	}
	
}

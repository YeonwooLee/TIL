package com.ssafy.hello.di2;

public class HelloMessageEng implements HelloMessage {

	public String hello(String name) {
		return "Hello " + name;
	}
	
}

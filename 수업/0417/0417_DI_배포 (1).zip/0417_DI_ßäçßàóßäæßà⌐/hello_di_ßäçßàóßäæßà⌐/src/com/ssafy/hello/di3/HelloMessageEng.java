package com.ssafy.hello.di3;

public class HelloMessageEng implements HelloMessage {

	public String hello(String name) {
		return "Hello " + name;
	}
	
}

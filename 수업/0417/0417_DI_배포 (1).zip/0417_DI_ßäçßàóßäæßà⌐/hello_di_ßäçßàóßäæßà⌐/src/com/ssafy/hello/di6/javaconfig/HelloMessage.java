package com.ssafy.hello.di6.javaconfig;

public interface HelloMessage {

	String hello(String name);
	
}

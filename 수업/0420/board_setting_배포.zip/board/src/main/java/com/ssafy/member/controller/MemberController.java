package com.ssafy.member.controller;

public class MemberController {

}

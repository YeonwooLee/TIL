<template>
  <div>
    <h2>게시판 뷰</h2>
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'BoardView',
};
</script>

<style></style>

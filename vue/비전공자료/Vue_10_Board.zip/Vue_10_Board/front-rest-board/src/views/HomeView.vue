<template>
  <div class="home">
    <img src="@/assets/ssafy_logo.png" />
    <h2>게시판 환영!</h2>
  </div>
</template>

<script>
export default {
  name: 'HomeView',
};
</script>

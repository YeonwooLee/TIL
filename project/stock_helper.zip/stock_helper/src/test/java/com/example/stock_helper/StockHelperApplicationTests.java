package com.example.stock_helper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockHelperApplicationTests {

	@Test
	void contextLoads() {
	}

}
